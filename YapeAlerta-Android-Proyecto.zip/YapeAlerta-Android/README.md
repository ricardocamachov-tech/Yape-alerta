# Yape Alerta (proyecto Android)

Aplicación Android nativa que escucha notificaciones de paquetes Yape conocidos, intenta extraer nombre y monto, anuncia el pago con TextToSpeech y suma los importes detectados por fecha local.

## Requisitos
- Android Studio (recomendado Ladybug o más reciente)
- JDK 17
- Android SDK Platform 35
- Android 8.0 (API 26) o superior

## Compilar
1. Abre la carpeta `YapeAlerta-Android` en Android Studio.
2. Espera a que Gradle sincronice y descargue las dependencias.
3. Selecciona `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. El APK debug estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Activar en el teléfono
1. Instala el APK.
2. Abre Yape Alerta.
3. Entra en **Configurar** y habilita el acceso a notificaciones para Yape Alerta.
4. Vuelve a la app y pulsa **Comprobar permiso**.
5. Asegúrate de que las notificaciones de Yape estén activadas en Android.
6. Para que lea con pantalla apagada, permite actividad en segundo plano y excluye Yape Alerta de la optimización de batería si el fabricante lo requiere.

## Limitaciones importantes
- No accede a la cuenta, movimientos internos, saldo ni credenciales de Yape; solo lee notificaciones visibles que Android entrega.
- El formato del aviso de Yape puede cambiar por versión, país o idioma. Las expresiones de extracción y los identificadores de paquete deben verificarse con una notificación real antes de confiar en el contador.
- El resumen es un registro de notificaciones detectadas, no una confirmación bancaria. Verifica siempre el abono en la app oficial.
- Esta primera versión mantiene datos localmente en el teléfono. No envía datos a servidores.
- El permiso de acceso a notificaciones es sensible: Android muestra una pantalla de autorización y el usuario debe concederlo manualmente.


## Compilar sin instalar Android Studio (GitHub Actions)
Esta carpeta incluye `.github/workflows/build-apk.yml`.
1. Crea un repositorio nuevo en GitHub desde el navegador del celular.
2. Sube el contenido de esta carpeta (descomprime primero el ZIP).
3. En el repositorio abre **Actions** y selecciona **Build Yape Alerta APK**.
4. Pulsa **Run workflow** y espera a que termine.
5. En la ejecución terminada, descarga el artefacto **YapeAlerta-debug-apk**. Dentro estará `app-debug.apk`.
6. Descarga el APK en el Android, ábrelo y autoriza la instalación desde esa fuente.

La compilación se realiza en GitHub; no requiere Android Studio en tu teléfono. Sí requiere una cuenta de GitHub y subir el proyecto.
