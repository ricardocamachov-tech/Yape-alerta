package com.yapealerta.app

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class YapeNotificationListener : NotificationListenerService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext, this)
    }
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("es", "PE")
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Package IDs may vary by Yape release/device. Only known Yape package IDs are accepted.
        val pkg = sbn.packageName.lowercase(Locale.ROOT)
        if (pkg !in YAPE_PACKAGES) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val parts = listOf(
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).filterNotNull().filter { it.isNotBlank() }
        val raw = parts.joinToString(" ")
        if (!raw.contains("yape", true) && !raw.contains("recib", true) && !raw.contains("te yap", true)) return
        val amount = extractAmount(raw) ?: return
        val name = extractName(raw)
        val now = Date()
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val time = SimpleDateFormat("HH:mm", Locale("es", "PE")).format(now)
        val id = "${sbn.key}|${sbn.postTime}|${amount}"
        val payment = Payment(id, name, amount, date, time)
        if (YapeStore.add(applicationContext, payment) && YapeStore.isVoiceEnabled(applicationContext)) {
            val spoken = if (name.isNotBlank() && name != "Persona no identificada")
                "Atención. Recibiste un Yape de ${amount.toInt()} soles de $name"
            else "Atención. Recibiste un Yape de ${amount.toInt()} soles"
            if (ttsReady) tts?.speak(spoken, TextToSpeech.QUEUE_ADD, null, id)
        }
    }
    private fun extractAmount(s: String): Double? {
        val patterns = listOf(
            Regex("(?i)S\\s*/?\\.?\\s*([0-9]{1,6}(?:[.,][0-9]{1,2})?)"),
            Regex("(?i)([0-9]{1,6}(?:[.,][0-9]{1,2})?)\\s*(?:soles|PEN)")
        )
        for (r in patterns) {
            val m = r.find(s) ?: continue
            val normalized = m.groupValues[1].replace(",", ".")
            normalized.toDoubleOrNull()?.let { if (it > 0) return it }
        }
        return null
    }
    private fun extractName(s: String): String {
        val patterns = listOf(
            Regex("(?i)(?:de|desde)\\s+([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ .'-]{1,45}?)(?:\\s+(?:te|por|S/?\\.?\\s*[0-9])|$)"),
            Regex("(?i)Yape\\s+de\\s+([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ .'-]{1,45})")
        )
        for (r in patterns) {
            val m = r.find(s) ?: continue
            return m.groupValues[1].trim().take(40)
        }
        return "Persona no identificada"
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
    companion object {
        private val YAPE_PACKAGES = setOf("com.bcp.innovacxion.yape", "com.bcp.yape")
        fun isPermissionGranted(context: Context): Boolean {
            val cn = ComponentName(context, YapeNotificationListener::class.java)
            val flat = android.provider.Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any { ComponentName.unflattenFromString(it) == cn }
        }
    }
}
