package com.yapealerta.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YapeAlertaScreen() }
    }
}

@Composable
fun YapeAlertaScreen() {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(YapeStore.isEnabled(context)) }
    var voiceEnabled by remember { mutableStateOf(YapeStore.isVoiceEnabled(context)) }
    var refresh by remember { mutableIntStateOf(0) }
    val payments = remember(refresh) { YapeStore.payments(context) }
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
    val todays = payments.filter { it.date == today }
    val total = todays.sumOf { it.amount }
    val money = NumberFormat.getCurrencyInstance(Locale("es", "PE"))

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF7027A5))) {
        Scaffold { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Yape Alerta", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Avisos hablados de pagos recibidos", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("TOTAL DETECTADO HOY", style = MaterialTheme.typography.labelMedium)
                            Text(money.format(total), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text("${todays.size} pagos detectados")
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Lectura por voz", fontWeight = FontWeight.SemiBold)
                                    Text("Dice el nombre y el monto de la notificación")
                                }
                                Switch(checked = voiceEnabled, onCheckedChange = {
                                    voiceEnabled = it; YapeStore.setVoiceEnabled(context, it)
                                })
                            }
                            Divider()
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Servicio de notificaciones", fontWeight = FontWeight.SemiBold)
                                    Text(if (enabled) "Permiso concedido (estado guardado)" else "Activa el acceso para detectar avisos")
                                }
                                Button(onClick = { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                                    Text("Configurar")
                                }
                            }
                            OutlinedButton(onClick = {
                                enabled = YapeNotificationListener.isPermissionGranted(context)
                                refresh++
                            }, modifier = Modifier.fillMaxWidth()) { Text("Comprobar permiso") }
                        }
                    }
                }
                item { Text("Pagos de hoy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                if (todays.isEmpty()) {
                    item { Text("Todavía no se detectaron pagos hoy.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    items(todays.reversed()) { p ->
                        Card {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(p.time, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(money.format(p.amount), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                item {
                    Text("Nota: el total suma solo notificaciones que Yape entregue y que la app pueda interpretar. Verifica cada abono en Yape antes de entregar productos.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
