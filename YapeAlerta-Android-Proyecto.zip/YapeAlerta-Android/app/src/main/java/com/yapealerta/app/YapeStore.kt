package com.yapealerta.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Payment(val id: String, val name: String, val amount: Double, val date: String, val time: String)

object YapeStore {
    private const val PREF = "yape_alerta"
    private const val PAYMENTS = "payments"
    fun isEnabled(c: Context) = c.getSharedPreferences(PREF, 0).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) { c.getSharedPreferences(PREF, 0).edit().putBoolean("enabled", v).apply() }
    fun isVoiceEnabled(c: Context) = c.getSharedPreferences(PREF, 0).getBoolean("voice", true)
    fun setVoiceEnabled(c: Context, v: Boolean) { c.getSharedPreferences(PREF, 0).edit().putBoolean("voice", v).apply() }
    @Synchronized fun add(c: Context, p: Payment): Boolean {
        val prefs = c.getSharedPreferences(PREF, 0)
        val arr = JSONArray(prefs.getString(PAYMENTS, "[]"))
        for (i in 0 until arr.length()) if (arr.optJSONObject(i)?.optString("id") == p.id) return false
        val obj = JSONObject().put("id", p.id).put("name", p.name).put("amount", p.amount)
            .put("date", p.date).put("time", p.time)
        arr.put(obj)
        prefs.edit().putString(PAYMENTS, arr.toString()).apply()
        return true
    }
    fun payments(c: Context): List<Payment> {
        val arr = JSONArray(c.getSharedPreferences(PREF, 0).getString(PAYMENTS, "[]"))
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { o ->
                Payment(o.optString("id"), o.optString("name"), o.optDouble("amount"),
                    o.optString("date"), o.optString("time"))
            }
        }
    }
}
